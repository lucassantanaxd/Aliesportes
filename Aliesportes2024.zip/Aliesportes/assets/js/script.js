'use strict';



/**
 * add event on element
 */

const addEventOnElem = function (elem, type, callback) {
  if (elem.length > 1) {
    for (let i = 0; i < elem.length; i++) {
      elem[i].addEventListener(type, callback);
    }
  } else {
    elem.addEventListener(type, callback);
  }
}



/**
 * navbar toggle
 */

const navbar = document.querySelector("[data-navbar]");
const navTogglers = document.querySelectorAll("[data-nav-toggler]");
const navLinks = document.querySelectorAll("[data-nav-link]");

const toggleNavbar = function () { navbar.classList.toggle("active"); }

addEventOnElem(navTogglers, "click", toggleNavbar);

const closeNavbar = function () { navbar.classList.remove("active"); }

addEventOnElem(navLinks, "click", closeNavbar);



/**
 * header & back top btn active
 */

const header = document.querySelector("[data-header]");
const backTopBtn = document.querySelector("[data-back-top-btn]");

window.addEventListener("scroll", function () {
  if (window.scrollY >= 100) {
    header.classList.add("active");
    backTopBtn.classList.add("active");
  } else {
    header.classList.remove("active");
    backTopBtn.classList.remove("active");
  }
});
// Selecione todos os botões "Mostrar Mais"
const showMoreButtons = document.querySelectorAll('.show-more-button');

// Adicione um ouvinte de evento de clique a cada botão
showMoreButtons.forEach((button) => {
    button.addEventListener('click', () => {
        // Encontre o elemento pai do botão (div.result)
        const resultElement = button.closest('.result');

        // Encontre o elemento de informações adicionais dentro do resultado
        const additionalInfo = resultElement.querySelector('.additional-info');

        // Alternar a visibilidade das informações adicionais
        if (additionalInfo.style.display === 'none' || additionalInfo.style.display === '') {
            additionalInfo.style.display = 'block';
            button.textContent = 'Fechar';
        } else {
            additionalInfo.style.display = 'none';
            button.textContent = 'Mostrar Mais';
        }
    });
});

// Referencie o botão e o texto que deseja copiar
const copyButton = document.getElementById("copyButton");
const textoParaCopiar = "Este é o texto que será copiado.";

// Adicione um ouvinte de eventos de clique ao botão
copyButton.addEventListener("click", () => {
    // Cria um elemento de área de texto temporário para a cópia
    const tempTextArea = document.createElement("textarea");
    tempTextArea.value = textoParaCopiar;

    // Adiciona o elemento temporário à página
    document.body.appendChild(tempTextArea);

    // Seleciona o texto no elemento de área de texto
    tempTextArea.select();
    
    // Copia o texto para a área de transferência
    document.execCommand("copy");

    // Remove o elemento temporário da página
    document.body.removeChild(tempTextArea);

    // Mostra uma mensagem de confirmação (opcional)
    alert("Texto copiado para a área de transferência!");
});
