// Selecione todos os botões "Mostrar Mais"
const showMoreButtons = document.querySelectorAll('.show-more-button');

// Adicione um ouvinte de evento de clique a cada botão
showMoreButtons.forEach((button) => {
    button.addEventListener('click', () => {
        // Encontre o elemento pai do botão (div.result)
        const resultElement = button.closest('.result');

        // Encontre o elemento de informações adicionais dentro do resultado
        const additionalInfo = resultElement.querySelector('.additional-info');

        // Alternar a visibilidade das informações adicionais
        if (additionalInfo.style.display === 'none' || additionalInfo.style.display === '') {
            additionalInfo.style.display = 'block';
            button.textContent = 'Fechar';
        } else {
            additionalInfo.style.display = 'none';
            button.textContent = 'Mostrar Mais';
        }
    });
});
