<?php

// Incluir o arquivom com a conexão com banco de dados
include_once './conexao.php';

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listar as Avaliacoes</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="css/list.css">
    <link rel="shortcut icon" href="logo.svg" type="image/svg+xml">  
</head>

<body>
<div class="header">
    <a class="logo" href="../index.php">
    <img src="logo.svg" alt="Logo da AliEsportes" style="height: 60px; margin-right: 15px;" aria-hidden="true">
        <span class="span">AliEsportes</span>
      
    </a>
   
    <a>
    
    <a href="../index.php">
    <button class="botao-sair" >Voltar para o site</button>
</a>

  </div>
  
    <!-- Criar menu básico -->
    <br><br><br>
    <!-- Criar menu básico -->

    <div class="tx">
    <a href="index.php">Avaliar</a>
    <a href="listar_avaliacoes.php">Listar</a><br>
</div>
    <h1>Avaliações dos Usuários</h1>

    <?php

    // Recuperar as avaliações do banco de dados
    $query_avaliacoes = "SELECT id, qtd_estrela, mensagem 
                        FROM avaliacoes
                        ORDER BY id DESC";

    // Preparar a QUERY
    $result_avaliacoes = $conn->prepare($query_avaliacoes);

    // Executar a QUERY
    $result_avaliacoes->execute();

    // Percorrer a lista de registros recuperada do banco de dados
    while ($row_avaliacao = $result_avaliacoes->fetch(PDO::FETCH_ASSOC)) {
        //var_dump($row_avaliacao);

        // Extrair o array para imprimir pelo nome do elemento do array
        extract($row_avaliacao);

        echo "<p>Avaliação: $id</p>";

        // Criar o for para percorrer as 5 estrelas
        for ($i = 1; $i <= 5; $i++) {

            // Acessa o IF quando a quantidade de estrelas selecionadas é menor a quantidade de estrela percorrida e imprime a estrela preenchida
            if ($i <= $qtd_estrela) {
                echo '<i class="estrela-preenchida fa-solid fa-star"></i>';
            } else {
                echo '<i class="estrela-vazia fa-solid fa-star"></i>';
            }
        }

        echo "<p>Mensagem: $mensagem</p><hr>";
    }
    ?>

</body>

</html>