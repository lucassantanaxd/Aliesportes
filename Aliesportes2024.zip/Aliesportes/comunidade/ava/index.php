<?php
session_start(); // Iniciar a sessão
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Avaliação - Aliesportes</title>
    <link rel="shortcut icon" href="logo.svg" type="image/svg+xml">  

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="css/custom1.css">
    <link rel="stylesheet" href="css/ava.css">
</head>
<div class="header">
    <a class="logo" href="../index.php">
    <img src="logo.svg" alt="../index.php" style="height: 60px; margin-right: 15px;" aria-hidden="true">
        <span class="span">AliEsportes</span>
      
    </a>
   
    <a>
    
    <a href="../index.php">
    <button class="botao-sair" >Voltar para o site</button>
</a>

  </div>
<body>
<?php
// Imprimir a mensagem de erro ou sucesso salva na sessão
if (isset($_SESSION['msg'])) {
    echo $_SESSION['msg'];
    unset($_SESSION['msg']);
}
?>

<!-- Inicio do formulário -->
<form method="POST" action="processa.php">

    <div class="container">
        <h1>Avalie Agora</h1>
        <div class="post">
            <div class="text">Obrigado por nos avaliar!</div>
        </div>
        <div class="star-widget">

            <!-- Carrega o formulário definindo nenhuma estrela selecionada -->
            <input type="radio" name="estrela" id="vazio" value="" checked>

            <!-- Opções para selecionar as estrelas -->
            <?php for ($i = 5; $i >= 1; $i--) : ?>
                <input type="radio" name="estrela" id="estrela_<?php echo $i; ?>" value="<?php echo $i; ?>">
                <label for="estrela_<?php echo $i; ?>" class="fas fa-star"></label>
            <?php endfor; ?>
        </div>

        <!-- Campo para enviar a mensagem -->
        <div class="textarea">
            <textarea name="mensagem" rows="4" cols="30" placeholder="Digite o seu comentário..."></textarea>
        </div>
        <div class="btn">
            <!-- Botão para enviar os dados do formulário -->
            <button type="submit">Publicar</button>
        </div>
    </div><div class="tx">
    <a href="index.php">Avaliar</a>
    <a href="listar_avaliacoes.php">Listar</a>
</div>
</form>
<!-- Fim do formulário -->

<!-- Fim do formulário -->

   
    </form>
    <!-- Fim do formulário -->
  <!-- Criar menu básico -->


</div>
</body>

</html>