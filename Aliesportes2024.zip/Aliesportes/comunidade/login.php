<?php 
  session_start();
  if(isset($_SESSION['unique_id'])){
    header("location: users.php");
  }
?>

<?php include_once "header.php"; ?>

<link rel="shortcut icon" href="logo.svg" type="image/svg+xml">  
<body>
  
<div class="header">
    <a class="logo" href="../index.php">
    <img src="logo.svg" alt="Logo da AliEsportes" style="height: 60px; margin-right: 15px;" aria-hidden="true">
        <span class="span">AliEsportes</span>
      
    </a>
   <a>
    
    <a href="">
    <button class="botao-sair" >Voltar para o site</button>
</a>
</a>
  </div>
  <div class="wrapper">
    <section class="form login">
      <header>Aplicativo de bate-papo em tempo real - Aliesportes </header>
      <form action="#" method="POST" enctype="multipart/form-data" autocomplete="off">
        <div class="error-text"></div>
        <div class="field input">
          <label>Endereço de email</label>
          <input type="text" name="email" placeholder="Digite seu e-mail" required>
        </div>
        <div class="field input">
          <label>Senha</label>
          <input type="password" name="password" placeholder="Entre com a sua senha" required>
          <i class="fas fa-eye"></i>
        </div>
        <div class="field button">
          <input type="submit" name="submit" value="Continuar para conversar">
        
        </div>
      </form>
      <div class="link">Ainda não se inscreveu? <a href="index.php">  Inscreva-se agora</a></div>
      
    </section>
  </div>
  
  <script src="javascript/pass-show-hide.js"></script>
  <script src="javascript/login.js"></script>

</body>
</html>
