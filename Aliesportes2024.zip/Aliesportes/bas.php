

<!DOCTYPE html>
<html lang="pt">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>AliEsportes - Basquete</title>

  <!-- 
    - favicon
  -->
  <link rel="shortcut icon" href="./logo.svg" type="image/svg+xml">

  <!-- 
    - custom css link
  -->
  <link rel="stylesheet" href="./assets/css/bas.css">

  <!-- 
    - google font link
  -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link
    href="https://fonts.googleapis.com/css2?family=Catamaran:wght@600;700;800;900&family=Rubik:wght@400;500;800&display=swap"
    rel="stylesheet">

  <!-- 
    - preload images
  -->
  <link rel="preload" as="image" href="./assets/images/hero-banner.png">
  <link rel="preload" as="image" href="./assets/images/hero-circle-one.png">
  <link rel="preload" as="image" href="./assets/images/hero-circle-two.png">
  <link rel="preload" as="image" href="./assets/images/heart-rate.svg">
  <link rel="preload" as="image" href="./assets/images/calories.svg">

</head>

<body id="top">

  <!-- 
    - #HEADER
  -->

  <header class="header" data-header>
    <div class="container">

      <a href="index.php" class="logo">
        <img src="./logo.svg" alt="Logo da AliEsportes" aria-hidden="true">
        <span class="span">AliEsportes</span>
      </a>
      

      <nav class="navbar" data-navbar>

        <button class="nav-close-btn" aria-label="close menu" data-nav-toggler>
          <ion-icon name="close-sharp" aria-hidden="true"></ion-icon>
        </button>

        <ul class="navbar-list">

      
          <li>
            <a href="index.php#home" class="navbar-link active" data-nav-link>Inicio</a>
          </li>

          <li>
            <a href="index.php#about" class="navbar-link" data-nav-link>Sobre Nós</a>
          </li>

          <li>
            <a href="index.php#class" class="navbar-link" data-nav-link>Locais</a>
          </li>

          <li>
            <a href="index.php#blog" class="navbar-link" data-nav-link>Noticias</a>
            </li>
            </li>
          <a href="comunidade/ava/index.php" class="navbar-link" data-nav-link>Avaliações</a>
          <li>
            <a href="../aliesportes/comunidade/login.php" class="navbar-link" data-nav-link>Chat</a>
          <li>
            <a href="index.php#footer" class="navbar-link" data-nav-link>Contate-nos</a>
          </li>
          
        </ul>

      </nav>



      <button class="nav-open-btn" aria-label="open menu" data-nav-toggler>
        <span class="line"></span>
        <span class="line"></span>
        <span class="line"></span>
      </button>

    </div>
  </header>





  <main>
    <article>

      <!-- 
        - #HERO
      -->

      <section class="section hero bg-dark has-after has-bg-image" id="home" aria-label="hero" data-section
        style="background-image: url('./assets/images/hero-bg.png')">
        <div class="container">

          <div class="hero-content">

            <p class="hero-subtitle">
              <strong class="strong">Basquete</strong>Para os seus Esportes
            </p>

            <h1 class="h1 hero-title">Melhores Locais perto de você</h1>

            <p class="section-text">
              Encontramos para você os melhores locais
            </p>

            <a href="#blog" class="btn btn-primary">Clique Aqui</a>

          </div>

          <div class="hero-banner">

            <img src="./assets/images/01.png" width="660" height="753" alt="hero banner" class="w-100">

            <img src="./assets/images/hero-circle-one.png" width="666" height="666" aria-hidden="true" alt=""
              class="circle circle-1">
            <img src="./assets/images/hero-circle-two.png" width="666" height="666" aria-hidden="true" alt=""
              class="circle circle-2">

            <img src="./assets/images/heart-rate.svg" width="255" height="270" alt="heart rate"
              class="abs-img abs-img-1">
            <img src="./assets/images/calories.svg" width="348" height="224" alt="calories" class="abs-img abs-img-2">

          </div>

        </div>
        
      </section>

     
        
        <div class="container">
            <main>
                <section class="search-locations">
                  <div class="container">
                    <main>
                      
                            <div class="category-button">
                            <div class="category-button">
                              <button class="rounded-button button-color-1"><a href="volei.php">Vôlei</a></button>
              
                                <button class="rounded-button button-color-3"><a href="fut.php">Futebol</a></button>
                                <button class="rounded-button button-color-4" ><a href="academy.php">Academia</a></button>
                            </div>
                        </section>
                    </main>
                </div>
                
                    </form>
                </section>
        
                <section class="section blog" id="blog" aria-label="blog">
                    <div class="container">
            
                      <p class="section-subtitle">Resultados</p>
            
                      <h2 class="h2 section-title text-center">Quadras/Campos</h2>
            
                      <ul class="blog-list has-scrollbar">
            
                        <li class="scrollbar-item">
                          <div class="blog-card">
            
                            <div class="card-banner img-holder" style="--width: 440; --height: 270;">
                              <img src="./assets/images/blog-11.jpg" width="440" height="270" loading="lazy"
                                alt="Going to the gym for the first time" class="img-cover">
            
                              <time class="card-meta" datetime="2022-07-07">Gratuito</time>
                            </div>
            
                            <div class="card-content">
            
                              <h3 class="h3">
                                <a href="https://maps.app.goo.gl/A9mbXNhMf8dsAFMY8" class="card-title">QUADRA E CAMPO </a>
                              </h3>
            
                              <p class="card-text">
                                PARQUE DO CENTENÁRIO “DR. ODAYR ALVES DA SILVA”
                              </p>
            
                              <a href="https://maps.app.goo.gl/A9mbXNhMf8dsAFMY8" class="btn-link has-before">MOSTRAR ROTA</a>
            
                            </div>
            
                          </div>
                        </li>
            
                        <li class="scrollbar-item">
                          <div class="blog-card">
            
                            <div class="card-banner img-holder" style="--width: 440; --height: 270;">
                              <img src="./assets/images/QUADRA1.jpg" width="440" height="270" loading="lazy"
                                alt="Parturient accumsan cacus pulvinar magna" class="img-cover">
            
                              <time class="card-meta" datetime="2022-07-07">Gratuito</time>
                            </div>
            
                            <div class="card-content">
            
                              <h3 class="h3">
                                <a href="https://maps.app.goo.gl/jCBF5mF1nMctMjpw5" class="card-title">QUADRA SÃO JOSE</a>
                              </h3>
            
                              <p class="card-text">
                                Rua João Alexandre, 143-173 - Vila Sao Jose, Ourinhos - SP, 19905-030

                              </p> 
            
                              <a href="https://maps.app.goo.gl/jCBF5mF1nMctMjpw5" class="btn-link has-before">MOSTRAR ROTA</a>
            
                            </div>
            
                          </div>
                        </li>
            
                        <li class="scrollbar-item">
                          <div class="blog-card">
            
                            <div class="card-banner img-holder" style="--width: 440; --height: 270;">
                              <img src="./assets/images/02.jpg" width="440" height="270" loading="lazy"
                                alt="Risus purus namien parturient accumsan cacus" class="img-cover">
            
                              <time class="card-meta" datetime="2022-07-07">Gratuito</time>
                            </div>
            
                            <div class="card-content">
            
                              <h3 class="h3">
                                <a href="https://maps.app.goo.gl/dUmuWoRVGqTtR8ey5" class="card-title">PRAÇA KENNEDY </a>
                              </h3>
            
                              <p class="card-text">
                                QUADRA DE BASQUETE - Jardim Europa, Ourinhos - SP, 19914-420
            
                              </p>
            
                              <a href="https://maps.app.goo.gl/dUmuWoRVGqTtR8ey5" class="btn-link has-before">MOSTRAR ROTA</a>
            
                            </div>
            
                          </div>
                        </li>
            
                      </ul>
            
                    </div>
                  </section>
         
         </div>



          

      <!-- 
        - #VIDEO
      -->




     

      

    </article>
  </main>





  <!-- 
    - #FOOTER
  -->

  <footer class="footer">

    <div class="section footer-top bg-dark has-bg-image" style="background-image: url('./assets/images/footer-bg.png')">
      <div class="container">

        <div class="footer-brand">

          <a href="#" class="logo">
            <img src="./logo.svg" alt="Logo da AliEsportes" aria-hidden="true">

            <span class="span">AliEsportes</span>
          </a>

          <p class="footer-brand-text">
            © 2023 AliEsportes. Todos os direitos reservados. Desenvolvido por Lucas & Felipe.
          </p>

          <div class="wrapper">

            <img src="./assets/images/footer-clock.png" width="34" height="34" loading="lazy" alt="Clock">

            <ul class="footer-brand-list">

              <li>
                <p class="footer-brand-title">Segunda - Sexta</p>

                <p>7:00Am - 10:00Pm</p>
              </li>

              <li>
                <p class="footer-brand-title">Sábado - Domingo</p>

                <p>7:00Am - 2:00Pm</p>
              </li>

            </ul>

          </div>

        </div>

        <ul class="footer-list">

   
          <li>
            <p class="footer-list-title has-before">Outros Links</p>
          </li>

          <li>
            <a href="index.php#home" class="footer-link">Inicio</a>
          </li>

          <li>
            <a href="index.php#about" class="footer-link">Sobre</a>
          </li>

          <li>
            <a href="index.php#class" class="footer-link">Locais</a>
          </li>

          <li>
            <a href="index.php#blog" class="footer-link">Noticias</a>
          </li>

          <li>
            <a href="index.php#footer" class="footer-link">Contate-nos</a>
          </li>


        </ul>

        <ul class="footer-list">

          <li>
            <p class="footer-list-title has-before">Contate-nos</p>
          </li>

          <li class="footer-list-item">
            <div class="icon">
              <ion-icon name="location" aria-hidden="true"></ion-icon>
            </div>

            <address class="address footer-link">
          Campus Experimental de Ourinhos - Av. Vitalina Marcusso, 1400 Ourinhos - SP, 19910-206
            </address>
          </li>

          <li class="footer-list-item">
            <div class="icon">
              <ion-icon name="call" aria-hidden="true"></ion-icon>
            </div>

            <div>
              <a href="tel:18001213637" class="footer-link">14998849753</a>

              <a href="tel:+915552348765" class="footer-link">+55 14998849753</a>
            </div>
          </li>

          <li class="footer-list-item">
            <div class="icon">
              <ion-icon name="mail" aria-hidden="true"></ion-icon>
            </div>

            <div>
              <a href="mailto:info@fitlife.com" class="footer-link">contato@aliesportes.com</a>

              <a href="mailto:services@fitlife.com" class="footer-link">services@aliesportes.com</a>
            </div>
          </li>

        </ul>

        <ul class="footer-list">

          <li>
            <p class="footer-list-title has-before">Nosso boletim informativo</p>
          </li>

          <li>
            <form action="" class="footer-form">
              <input type="email" name="email_address" aria-label="email" placeholder="Envie seu Email " required
                class="input-field">

              <button type="submit" class="btn btn-primary" aria-label="Submit">
                <ion-icon name="chevron-forward-sharp" aria-hidden="true"></ion-icon>
              </button>
            </form>
          </li>

          <li>
            <ul class="social-list">

              <li>
                <a href="#" class="social-link">
                  <ion-icon name="logo-facebook"></ion-icon>
                </a>
              </li>

              <li>
                <a href="https://www.instagram.com/aliesportesoficial/" class="social-link">
                  <ion-icon name="logo-instagram"></ion-icon>
                </a>
              </li>

              <li>
                <a href="#" class="social-link">
                  <ion-icon name="logo-twitter"></ion-icon>
                </a>
              </li>

            </ul>
          </li>

        </ul>

      </div>
    </div>

    <div class="footer-bottom">
      <div class="container">

        <p class="copyright">
          &copy; 2023 AliEsportes. todos os direitos reservados <a href="#" class="copyright-link">Lucas e Felipe.</a>
        </p>

        <ul class="footer-bottom-list">

          <li>
            <a href="#" class="footer-bottom-link has-before">Política de Privacidade</a>
          </li>

          <li>
            <a href="#" class="footer-bottom-link has-before">Termos e Condições</a>
          </li>

        </ul>

      </div>
    </div>

  </footer>





  <!-- 
    - #BACK TO TOP
  -->

  <a href="#top" class="back-top-btn" aria-label="back to top" data-back-top-btn>
    <ion-icon name="caret-up-sharp" aria-hidden="true"></ion-icon>
  </a>





  <!-- 
    - custom js link
  -->
  <script src="./assets/js/script.js" defer></script>

  <!-- 
    - ionicon link
  -->
  <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>

</body>

</html>